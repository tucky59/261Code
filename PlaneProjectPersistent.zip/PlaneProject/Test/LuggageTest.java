import org.junit.Test;

import static org.junit.Assert.*;

public class LuggageTest {

    @Test
    public void getWeight() {
        Luggage l1 = new Luggage(30,10);
        l1.setWeight(30);
        assertEquals(30,l1.getWeight());
    }

    @Test
    public void setWeight() {
        Luggage l1 = new Luggage(30,10);
        l1.setWeight(20);
        assertEquals(20,l1.getWeight());
    }

    @Test
    public void getCost() {
        Luggage l2 = new Luggage(30,10);
        assertEquals(10,l2.getCost());
    }

    @Test
    public void setCost() {
        Luggage l2 = new Luggage(30,10);
        l2.setCost(45);
        assertEquals(45,l2.getCost());
    }

    @Test
    public void testToString() {
        Luggage luggage = new Luggage(45,10);
        assertEquals("Weight: 45 Cost: 10", luggage.toString());
    }
}