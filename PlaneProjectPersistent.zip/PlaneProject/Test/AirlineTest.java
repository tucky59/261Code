import org.junit.Test;

import static org.junit.Assert.*;

public class AirlineTest {

    @Test
    public void getAirlineName() {
        Airline a1 = new Airline("Jetblue","Airbus");
        assertEquals("Jetblue", a1.getAirlineName());
    }

    @Test
    public void setAirlineName() {
        Airline a1 = new Airline("Jetblue","Airbus");
        a1.setAirlineName("Delta");
        assertEquals("Delta", a1.getAirlineName());
    }

    @Test
    public void getPlaneModel() {
        Airline a1 = new Airline("Jetblue","Airbus");
        assertEquals("Jetblue", a1.getAirlineName());
    }

    @Test
    public void setPlaneModel() {
        Airline a2 = new Airline("Delta","Boeing");
        a2.setPlaneModel("Airbus");
        assertEquals("Airbus",a2.getPlaneModel());
    }

    @Test
    public void testToString() {
        Airline airline = new Airline("Jetblue", "Airbus A320");
        assertEquals("Airline Name: Jetblue Plane Model: Airbus A320", airline.toString());

    }
}