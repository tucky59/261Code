import java.util.ArrayList;

public class main {
    public static void main(String[] args) {
        //Flight flight = new Flight("605A", "6/24", "3:30", "7:30", "4:00", "Orlando");
        //Airline airline = new Airline("Jetblue", "Airbus A320");
// Airport airport = new Airport("JFK","New York","Orlando");
        //Luggage luggage = new Luggage(45,10);
// Person person = new Person("Austin","Ausitinwhitson42@gmail.com",20);
// TestHarness th = new TestHarness();
        //System.out.println(flight);
        // System.out.println(airline);
//        System.out.println(airport);
        //  System.out.println(luggage);
//        System.out.println(person);

      AirlineListCntl alc = new AirlineListCntl();
        LuggageList luggageList = new LuggageList();
     //  updateLuggaeList(luggageList);
        luggageList.writeLuggageListFile();
       luggageList.printLuggageListFile();
    }

    public static void updateLuggaeList(LuggageList luggageList)
    {
       Luggage l1 = new Luggage(25,7);
        ArrayList<Luggage> luggageArrayList = luggageList.getLuggageArrayList();
        luggageArrayList.add(l1);
        luggageArrayList.set(0,new Luggage(50,33));

    //*********    AirlineCntl ac = new AirlineCntl();   ***********


       // Pilot p1 = new Pilot("Mark","mark@pilot.com",50,4342,15);
      //  Pilot p2 = new Pilot("Austin","Austin@pilot.com",20,41248,5);
      //  Flyer f1 = new Flyer("Jonnell","Jonnell@gmail.com",40,1234,"None","None");
       // Flyer f2 = new Flyer("Ben","Ben@gmail.com",22,234245,"Dog","None");
//        ArrayList<Person> Persons = new ArrayList<>();
//        Persons.add(p1);
//        Persons.add(p2);
//        Persons.add(f1);
//        Persons.add(f2);
//
//        for(Person p: Persons)
//        {
//            System.out.println(p.toString());
//            p.Approved();
//        }

//        ArrayList<Printable> printableObjects = new ArrayList<>();
//        printableObjects.add(p1);
//        printableObjects.add(f1);
//        for(Printable p: printableObjects)
//        {
//            p.printSetup();
//            p.print();
//        }



    }
}
