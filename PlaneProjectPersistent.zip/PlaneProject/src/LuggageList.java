import java.io.*;
import java.util.ArrayList;

public class LuggageList {
    private String luggageFileName = "ListOfLuggage.ser";
    private ArrayList<Luggage> luggageArrayList = new ArrayList<>();

    public LuggageList()
    {
        this.readLuggageListFile();
        if(luggageArrayList.isEmpty() || luggageArrayList == null)
        {
            this.createLuggageList();
            this.writeLuggageListFile();
            this.readLuggageListFile();
        }
        printLuggageListFile();
    }

    public void createLuggageList()
    {
        Luggage l1 = new Luggage(50,10);
        Luggage l2 = new Luggage(30,5);
        Luggage l3  = new Luggage(70,20);
        luggageArrayList.add(l1);
        luggageArrayList.add(l2);
        luggageArrayList.add(l3);

    }

    public void readLuggageListFile()
    {
        FileInputStream fis = null;
        ObjectInputStream in = null;
        try{
            fis = new FileInputStream(luggageFileName);
            in = new ObjectInputStream(fis);
            luggageArrayList = (ArrayList)in.readObject();
            in.close();
            if(!luggageArrayList.isEmpty())
            {
                System.out.println("There are users in the file");
            }

        } catch (FileNotFoundException fne)
        {
            System.out.println("File not found, file will be created");
        } catch (IOException ex)
        {
            ex.printStackTrace();
        } catch (ClassNotFoundException ex)
        {
            ex.printStackTrace();
        }
    }

    public void writeLuggageListFile()
    {
        FileOutputStream fos = null;
        ObjectOutputStream out = null;
        try{
            fos = new FileOutputStream(luggageFileName);
            out = new ObjectOutputStream(fos);
            out.writeObject(luggageArrayList);
            out.close();

        } catch (IOException ex)
        {
            ex.printStackTrace();
        }
    }

public void printLuggageListFile()
{
    System.out.println("The luggage list has these objects ");
    for(Luggage l: luggageArrayList)
    {
        System.out.println(l.toString());
    }
}

    public ArrayList<Luggage> getLuggageArrayList() {
        return luggageArrayList;
    }

    public void setLuggageArrayList(ArrayList<Luggage> luggageArrayList) {
        this.luggageArrayList = luggageArrayList;
    }
}
