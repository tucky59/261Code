import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AirlineListUI extends JFrame {
    private JPanel tabelPanel, buttonPanel;
    private JTable airlineTable;
    private JButton doneButton, detailsButton, newButton;
    private JScrollPane tableScroller;
    private AirlineListCntl airlineListCntl;

    public AirlineListUI(AirlineListCntl airlineListCntl) {
        this.airlineListCntl = airlineListCntl;
        this.setSize(500, 500);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        initComponents();
    }

    public void initComponents() {
        tabelPanel = new JPanel();
        buttonPanel = new JPanel(new GridLayout(1, 4));
        airlineTable = new JTable(airlineListCntl.getTheAirlineTableModel());
        airlineTable.getColumnModel().getColumn(1).setPreferredWidth(20);
        doneButton = new JButton("Done");
        doneButton.addActionListener(new DoneButtonListener());
        newButton = new JButton("Add New Airline");
        newButton.addActionListener(new newButtonListener());
        detailsButton = new JButton("Get Airline Details");
        detailsButton.addActionListener(new DetailsButtonListener());
        buttonPanel.add(newButton);
        buttonPanel.add(detailsButton);
        buttonPanel.add(doneButton);
        tableScroller = new JScrollPane(airlineTable);
        airlineTable.setFillsViewportHeight(true);
        tableScroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        tableScroller.setPreferredSize(new Dimension(400, 400));
        tabelPanel.add(tableScroller);
        this.setTitle("Airline List");
        this.setLocationRelativeTo(null);
        this.setContentPane(new JPanel(new BorderLayout()));
        //this.getContentPane().add(new JLabel("New JLabel"), BorderLayout.NORTH);
        this.getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        this.getContentPane().add(tabelPanel, BorderLayout.CENTER);

    }

    class DetailsButtonListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedTableRow = airlineTable.getSelectedRow();
            int selectedModelRow = airlineTable.convertRowIndexToModel(selectedTableRow);
            if (selectedModelRow == -1) {
                selectedModelRow = 0;
            }
            AirlineListUI.this.airlineListCntl.getAirlineDetailUI(selectedModelRow);
        }

    }

    class DoneButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            System.exit(0);
        }
    }

    class newButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e)
        {
      AirlineListUI.this.airlineListCntl.newAirline();
        }
    }
}
