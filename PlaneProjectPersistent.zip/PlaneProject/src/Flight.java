public class Flight {
    private String flightNumber, flightDate, flightTime, arrival, depature, destionation;

    public Flight(String flightNumber, String flightDate, String flightTime, String arrival, String depature, String destionation) {
        this.flightNumber = flightNumber;
        this.flightDate = flightDate;
        this.flightTime = flightTime;
        this.arrival = arrival;
        this.depature = depature;
        this.destionation = destionation;
    }

    public Flight()
    {
        flightNumber = "Flight Number";
        flightDate = "Flight Date";
        flightTime = "Flight Time";
        arrival = "Arrival";
        depature = "Depature";
        destionation = "Destionation";
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }

    public String getFlightDate() {
        return flightDate;
    }

    public void setFlightDate(String flightDate) {
        this.flightDate = flightDate;
    }

    public String getFlightTime() {
        return flightTime;
    }

    public void setFlightTime(String flightTime) {
        this.flightTime = flightTime;
    }

    public String getArrival() {
        return arrival;
    }

    public void setArrival(String arrival) {
        this.arrival = arrival;
    }

    public String getDepature() {
        return depature;
    }

    public void setDepature(String depature) {
        this.depature = depature;
    }

    public String getDestionation() {
        return destionation;
    }

    public void setDestionation(String destionation) {
        this.destionation = destionation;
    }

    @Override
    public String toString()
    {
        return "Flight number: "+ flightNumber + " Flight Date: "+ flightDate + " Flight time: "+ flightTime+ "\n Arrival time: "+ arrival + " Departure time: "+ depature + " Destionation: "+ destionation;
    }
}
