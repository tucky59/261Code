import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;

public class AirlineTableModel extends AbstractTableModel {

    private String[] columnNames = {"Airline Name","Plane Model"};
    private ArrayList<Airline> airlineArrayList;
    public AirlineTableModel(ArrayList<Airline> newAirlineArraylist)
    {
        airlineArrayList = newAirlineArraylist;
    }
    @Override
    public int getRowCount() {
        return airlineArrayList.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex){
            case 0: return (Object)airlineArrayList.get(rowIndex).getAirlineName();
            case 1: return (Object)airlineArrayList.get(rowIndex).getPlaneModel();
            default: return null;
        }
    }
 @Override
 public String getColumnName(int col)
 {
     return columnNames[col];
 }


}
