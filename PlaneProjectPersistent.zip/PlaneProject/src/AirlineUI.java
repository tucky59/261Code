import javax.swing.*;
import java.util.ArrayList;

public class AirlineUI extends JFrame {
    private JPanel panel1;
    private JTextField AirlineNameField;
    private JTextField PlaneModelField;
    public JButton previousButton;
    public JButton nextButton;
    public JButton addButton;
    public JButton updateButton;
    public JButton deleteButton;
    public JButton quitButton;
    public JButton saveButton;
    private JLabel lblMessage;
    private JButton saveNewAirline;
    private JButton listViewButton;
    private AirlineCntl theAirlineCntl;
    private AirlineListCntl theAirlineListCntl;
    private ArrayList<Airline> airlineArrayList;
    public int currentAirline = 0;


    public AirlineUI(AirlineCntl theAirlineCntl){
    this.theAirlineCntl = theAirlineCntl;
        airlineArrayList = theAirlineCntl.getTheAirlineList().getListOfAirlines();
        setUpUI();
    }

    public AirlineUI(AirlineListCntl theAirlineListCntl)
    {
        this.theAirlineListCntl = theAirlineListCntl;
        airlineArrayList = theAirlineListCntl.getAirlineArrayList();
        setUpUI();
    }

    public AirlineUI(AirlineCntl airlineCntl, int selectedRow) {
        currentAirline = selectedRow;
        airlineArrayList = airlineCntl.getTheAirlineList().getListOfAirlines();
        setUpUI();
    }

    public void setUpUI()
    {
        saveNewAirline.setVisible(false);
        populateAirlineFields();
        this.add(panel1);
        this.setSize(600,600);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setTitle("Airline Information");
    }

    public void populateAirlineFields()
    {
        AirlineNameField.setText(airlineArrayList.get(currentAirline).getAirlineName());
        PlaneModelField.setText(airlineArrayList.get(currentAirline).getPlaneModel());
    }

    public Airline getUpdatedAirline()
    {
        Airline airline = new Airline(AirlineNameField.getText(),PlaneModelField.getText());
        return airline;
    }

    public JButton getSaveNewAirline() {
        return saveNewAirline;
    }

    public String getLblMessage() {
        return lblMessage.getText();
    }

    public void setLblMessage(String lblMessage) {
        this.lblMessage.setText(lblMessage);
    }

    public String getAirlineName()
    {
        return AirlineNameField.getText();
    }

    public String getAirlineModel()
    {
        return PlaneModelField.getText();
    }

    public int getCurrentAirline() {
        return currentAirline;
    }

    public void setCurrentAirline(int currentAirline) {
        this.currentAirline = currentAirline;
    }

    public void removeAirline()
    {
        AirlineNameField.setText("");
        PlaneModelField.setText("");
        airlineArrayList.remove(currentAirline);
    }

    public void newAirline()
    {
        AirlineNameField.setText("");
        PlaneModelField.setText("");
        saveNewAirline.setVisible(true);
        addButton.setVisible(false);
        deleteButton.setVisible(false);
        nextButton.setVisible(false);
        previousButton.setVisible(false);
        updateButton.setVisible(false);

    }

    public JPanel getPanel1() {
        return panel1;
    }

    public void setPanel1(JPanel panel1) {
        this.panel1 = panel1;
    }

    public JButton getPreviousButton() {
        return previousButton;
    }

    public void setPreviousButton(JButton previousButton) {
        this.previousButton = previousButton;
    }

    public JButton getNextButton() {
        return nextButton;
    }

    public void setNextButton(JButton nextButton) {
        this.nextButton = nextButton;
    }

    public JButton getAddButton() {
        return addButton;
    }

    public void setAddButton(JButton addButton) {
        this.addButton = addButton;
    }

    public JButton getUpdateButton() {
        return updateButton;
    }

    public void setUpdateButton(JButton updateButton) {
        this.updateButton = updateButton;
    }

    public JButton getDeleteButton() {
        return deleteButton;
    }

    public void setDeleteButton(JButton deleteButton) {
        this.deleteButton = deleteButton;
    }

    public JButton getQuitButton() {
        return quitButton;
    }

    public void setQuitButton(JButton quitButton) {
        this.quitButton = quitButton;
    }

    public JButton getSaveButton() {
        return saveButton;
    }

    public void setSaveButton(JButton saveButton) {
        this.saveButton = saveButton;
    }

    public JButton getListViewButton() {
        return listViewButton;
    }

    public void setListViewButton(JButton listViewButton) {
        this.listViewButton = listViewButton;
    }
}
