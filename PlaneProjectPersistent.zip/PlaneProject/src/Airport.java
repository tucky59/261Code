public class Airport {
    private String locationInital, startLocation, endLocation;

    public Airport(String locationInital, String startLocation, String endLocation) {
        this.locationInital = locationInital;
        this.startLocation = startLocation;
        this.endLocation = endLocation;
    }

    public String getLocation() {
        return locationInital;
    }

    public void setLocation(String location) {
        this.locationInital = location;
    }

    public String getStartLocation() {
        return startLocation;
    }

    public void setStartLocation(String startLocation) {
        this.startLocation = startLocation;
    }

    public String getEndLocation() {
        return endLocation;
    }

    public void setEndLocation(String endLocation) {
        this.endLocation = endLocation;
    }

   @Override
   public String toString()
   {
       return locationInital + "\n Starting location: " + startLocation + "\n ending location: " + endLocation;
   }

}
