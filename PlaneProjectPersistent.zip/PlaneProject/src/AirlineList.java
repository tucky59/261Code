import java.io.*;
import java.util.ArrayList;

public class AirlineList {
    private String airlineFileName = "ListOfAirlines.ser";
    private ArrayList<Airline> listOfAirlines = new ArrayList<>();

    public AirlineList() {
        this.readAirlineListFile();
        if(listOfAirlines.isEmpty() || listOfAirlines == null)
        {
            this.createAirlineList();
          this.writeAirlineListFile();
          this.readAirlineListFile();
        }
        printAirlineList();
    }

    public void readAirlineListFile()
    {
        FileInputStream fis = null;
        ObjectInputStream in = null;
        try {
            fis = new FileInputStream(airlineFileName);
            in = new ObjectInputStream(fis);
            listOfAirlines = (ArrayList)in.readObject();
            in.close();
            if(!listOfAirlines.isEmpty())
            {
                System.out.println("There are users in the file");
            }
        } catch (FileNotFoundException fne){
            System.out.println("File not found, file will be created");
        } catch(IOException ex)
        {
            ex.printStackTrace();
        } catch (ClassNotFoundException ex){
            ex.printStackTrace();
        }
    }

    public void writeAirlineListFile()
    {
        FileOutputStream fos = null;
        ObjectOutputStream out = null;
        try{
            fos = new FileOutputStream(airlineFileName);
            out = new ObjectOutputStream(fos);
            out.writeObject(listOfAirlines);
            out.close();
        }catch (IOException ex){
            ex.printStackTrace();
        }
    }

    public void createAirlineList(){
        Airline a1 = new Airline("Jetblue", "A320");
        Airline a2 = new Airline("Delta", "A490");
        Airline a3 = new Airline("Southwest", "Boeing 747");
        listOfAirlines.add(a1);
        listOfAirlines.add(a2);
        listOfAirlines.add(a3);
    }
    public void printAirlineList()
    {
        System.out.println("The airline list has these objects");
        for(Airline a: listOfAirlines)
        {
            System.out.println(a.toString());
        }
    }




    public ArrayList<Airline> getListOfAirlines() {
        return listOfAirlines;
    }

    public void setListOfAirlines(ArrayList<Airline> airlineArrayList) {
        this.listOfAirlines = airlineArrayList;
    }
}

//    public void createAirlineList()
//    {
//        for(int i =1; i<11; i++)
//        {
//          Airline a = new Airline("Airline Name"+i,"Plane Model"+i);
//            listOfAirlines.add(a);
//        }
//    }


