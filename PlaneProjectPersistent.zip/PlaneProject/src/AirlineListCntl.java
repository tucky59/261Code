import java.util.ArrayList;

public class AirlineListCntl {
   private AirlineList theAirlineList = new AirlineList();
   private AirlineTableModel theAirlineTableModel;
    private AirlineListUI theAirlineListUI;
    private AirlineUI theAirlineUI;
    private AirlineCntl theAirlineCntl;

   public AirlineList getTheAirlineList()
   {
       return  theAirlineList;
   }

    public AirlineTableModel getTheAirlineTableModel() {
        return theAirlineTableModel;
    }


    public AirlineListCntl()
    {
    theAirlineTableModel = new AirlineTableModel(theAirlineList.getListOfAirlines());
    this.theAirlineListUI = new AirlineListUI(this);
    theAirlineListUI.setVisible(true);
    }

  public void getAirlineDetailUI(int selectedModelRow)
  {
      theAirlineListUI.dispose();
      theAirlineCntl = new AirlineCntl (this,selectedModelRow);
     // theAirlineUI.setVisible(true);
  }

  public void newAirline()
  {
      theAirlineListUI.dispose();
      theAirlineCntl = new AirlineCntl(this);
  }

   public ArrayList<Airline> getAirlineArrayList()
   {
       return theAirlineList.getListOfAirlines();
   }


    public void setTheAirlineList(AirlineList theAirlineList) {
        this.theAirlineList = theAirlineList;
    }

    public AirlineListUI getTheAirlineListUI() {
        return theAirlineListUI;
    }
}
