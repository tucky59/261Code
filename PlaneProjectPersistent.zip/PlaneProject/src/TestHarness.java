public class TestHarness {
    public TestHarness()
    {
testFlightClass();
testPersonClass();
    }

    public void testFlightClass()
    {
        System.out.println("Testing the Flight class");
        Flight f1 = new Flight();
        if(f1 != null)
        {
            System.out.println(f1.getArrival());
            System.out.println(f1.getDepature());
            System.out.println(f1.getFlightDate());
            System.out.println(f1.getDestionation());
            System.out.println(f1.getFlightTime());
            System.out.println(f1.getFlightNumber());
        }
        else
            System.out.println("There was an error getting the flight ");
            f1.setArrival("6:45");
            f1.setDepature("3:00");
            f1.setFlightDate("January 27th");
            f1.setDestionation("New York City");
            f1.setFlightTime("3:45");
            f1.setFlightNumber("123A");
            System.out.println(f1.toString());

    }


    public void testPersonClass()
    {
        System.out.println("Testing the person calss");
        Person p1 = new Person();
        if(p1 != null)
        {
            System.out.println(p1.getName());
            System.out.println(p1.getEmail());
            System.out.println(p1.getAge());
        }

        else
            System.out.println("There was an error getting the person class");
        p1.setName("Austin");
        p1.setEmail("firstlast@gmail.com");
        p1.setAge(20);
        System.out.println(p1.toString());
    }



}
