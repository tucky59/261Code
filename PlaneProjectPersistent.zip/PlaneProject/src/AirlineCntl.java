import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AirlineCntl implements ActionListener {
    private AirlineList theAirlineList;
    private AirlineUI theAirlineUI;
    private AirlineListCntl theAirlineListCntl;


    public AirlineListCntl getTheAirlineListCntl() {
        return theAirlineListCntl;
    }

    public AirlineCntl()
    {
        theAirlineList = new AirlineList();
        theAirlineUI = new AirlineUI(this);
        addActionListeners();
        theAirlineUI.setVisible(true);

    }

    public AirlineCntl(AirlineListCntl theAirlineListCntl)
    {theAirlineList = theAirlineListCntl.getTheAirlineList();
    this.theAirlineListCntl = theAirlineListCntl;
    theAirlineUI = new AirlineUI(theAirlineListCntl); //this
    addActionListeners();
    theAirlineUI.newAirline();
    theAirlineUI.setVisible(true);
    }

    public AirlineCntl(AirlineListCntl theAirlineListCntl, int selectedRow)
    {
        this.theAirlineListCntl = theAirlineListCntl;
        theAirlineList = theAirlineListCntl.getTheAirlineList();
        theAirlineUI = new AirlineUI(this,selectedRow);
        addActionListeners();
        theAirlineUI.setVisible(true);
    }

    public AirlineList getTheAirlineList()
    {
        return theAirlineList;
    }

    public void addActionListeners()
    {
        theAirlineUI.getAddButton().addActionListener(this);
        theAirlineUI.getNextButton().addActionListener(this);
        theAirlineUI.getDeleteButton().addActionListener(this);
        theAirlineUI.getPreviousButton().addActionListener(this);
        theAirlineUI.getQuitButton().addActionListener(this);
        theAirlineUI.getUpdateButton().addActionListener(this);
        theAirlineUI.getSaveNewAirline().addActionListener(this);
        theAirlineUI.getListViewButton().addActionListener(this);
      //  theAirlineUI.getSaveButton().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
    Object obj = e.getSource();
    theAirlineUI.setLblMessage("");

    if(obj == theAirlineUI.previousButton)
    {
        if(theAirlineUI.getCurrentAirline() <= theAirlineList.getListOfAirlines().size()-1)
        {
            theAirlineUI.setCurrentAirline(theAirlineUI.getCurrentAirline()-1);
        }
        
        else
            theAirlineUI.setCurrentAirline(0);
        theAirlineUI.populateAirlineFields();
    }
    if(obj == theAirlineUI.nextButton)
    {
        if(theAirlineUI.getCurrentAirline() < theAirlineList.getListOfAirlines().size()-1)
        {
            theAirlineUI.setCurrentAirline(theAirlineUI.getCurrentAirline()+1);
        }
        else
            theAirlineUI.setCurrentAirline(0);
        theAirlineUI.populateAirlineFields();
    }

     if(obj == theAirlineUI.addButton)
    {
        theAirlineUI.newAirline();
        theAirlineUI.setLblMessage("Enter new Airline fields and press save");
    }

    if (obj == theAirlineUI.getSaveNewAirline())
    {
        Airline airline = theAirlineUI.getUpdatedAirline();
        theAirlineList.getListOfAirlines().add(airline);
        theAirlineList.writeAirlineListFile();
        theAirlineUI.setLblMessage("New Airline was added");
        theAirlineUI.getNextButton().setVisible(true);
        theAirlineUI.getAddButton().setVisible(true);
        theAirlineUI.getSaveNewAirline().setVisible(false);
        theAirlineUI.getUpdateButton().setVisible(true);
        theAirlineUI.getPreviousButton().setVisible(true);
        theAirlineUI.getDeleteButton().setVisible(true);
    }

    if(obj == theAirlineUI.updateButton)
    {
        theAirlineList.getListOfAirlines().set(theAirlineUI.getCurrentAirline(),theAirlineUI.getUpdatedAirline()).setAirlineName(theAirlineUI.getAirlineName());
        theAirlineList.writeAirlineListFile();
        theAirlineUI.setLblMessage("Person record was updated");

    }

    if(obj == theAirlineUI.deleteButton)
    {
      theAirlineUI.removeAirline();
      theAirlineList.writeAirlineListFile();
    }

    if(obj == theAirlineUI.quitButton)
    {
        System.exit(0);
    }

    if(obj == theAirlineUI.saveButton)
    {
        Airline airline = theAirlineUI.getUpdatedAirline();
        theAirlineList.getListOfAirlines().add(airline);
        theAirlineUI.setLblMessage("New airline was added");
        theAirlineUI.nextButton.setVisible(true);
        theAirlineUI.addButton.setVisible(true);
        theAirlineUI.previousButton.setVisible(true);
        theAirlineUI.deleteButton.setVisible(true);
        theAirlineUI.saveButton.setVisible(false);
        theAirlineUI.updateButton.setVisible(true);


    }

    if(obj == theAirlineUI.getListViewButton())
    {
        theAirlineUI.dispose();
        theAirlineListCntl.setTheAirlineList(getTheAirlineList());
        getTheAirlineListCntl().getTheAirlineListUI().setVisible(true);
    }

    }
}
