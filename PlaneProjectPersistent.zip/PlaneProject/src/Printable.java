public interface Printable {
    public abstract  void printSetup();
    public abstract  void print();

}
