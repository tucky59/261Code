public class Pilot extends Person implements Printable{
    private int licenseNumber;
    private int yearsExpirence;
    private String banner;

    public Pilot(String name, String email, int age, int licenseNumber, int yearsExpirence)
    {
        super(name,email, age);
        this.licenseNumber = licenseNumber;
        this.yearsExpirence = yearsExpirence;
    }

    public int getLicenseNumber() {
        return licenseNumber;
    }

    public void setLicenseNumber(int licenseNumber) {
        this.licenseNumber = licenseNumber;
    }

    public int getYearsExpirence() {
        return yearsExpirence;
    }

    public void setYearsExpirence(int yearsExpirence) {
        this.yearsExpirence = yearsExpirence;
    }

    @Override
    public void Approved()
    {
        System.out.println("You are the pilot for this flight");
    }

    @Override
    public String toString()
    {
        return "Person information "+ super.toString()+ "\n License number: "+ licenseNumber+"\n Years Expirence: "+yearsExpirence;
    }
    @Override
    public void printSetup()
    {
        banner = "******* What is your pilot information *******";
    }

    public void print()
    {
        System.out.println(banner);
        System.out.println(this.toString());
    }

}
