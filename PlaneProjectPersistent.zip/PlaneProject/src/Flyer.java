public class Flyer extends Person implements Printable {
    private int tsaNumber;
    private String serviceAnimalType;
    private String wheelchairNeeded;
    private String banner;

    public Flyer(String name, String email, int age, int tsaNumber, String serviceAnimalType, String wheelchairNeeded)
    {
        super(name, email, age);
        this.tsaNumber = tsaNumber;
        this.serviceAnimalType = serviceAnimalType;
        this.wheelchairNeeded = wheelchairNeeded;
    }

    public int getTsaNumber() {
        return tsaNumber;
    }

    public void setTsaNumber(int tsaNumber) {
        this.tsaNumber = tsaNumber;
    }

    public String getServiceAnimalType() {
        return serviceAnimalType;
    }

    public void setServiceAnimalType(String serviceAnimalType) {
        this.serviceAnimalType = serviceAnimalType;
    }

    public String getWheelchairNeeded() {
        return wheelchairNeeded;
    }

    public void setWheelchairNeeded(String wheelchairNeeded) {
        this.wheelchairNeeded = wheelchairNeeded;
    }

    @Override
    public void Approved()
    {
        System.out.println("Your information checks out");
    }

    @Override
    public String toString()
    {
        return "Person information "+ super.toString()+ "\n TSA number: "+ tsaNumber+"\n Service animal required: "+ serviceAnimalType+ "\n Wheel chair needed: "+wheelchairNeeded;

    }
    @Override
    public void printSetup()
    {
        banner = "******* What is your Flyer information *******";
    }

    public void print()
    {
        System.out.println(banner);
        System.out.println(this.toString());
    }

}
