import java.io.Serializable;

public class Airline implements Serializable {
    private String airlineName, planeModel;

    public Airline(String airlineName, String planeModel) {
        this.airlineName = airlineName;
        this.planeModel = planeModel;
    }

    public String getAirlineName() {
        return airlineName;
    }

    public void setAirlineName(String airlineName) {
        this.airlineName = airlineName;
    }

    public String getPlaneModel() {
        return planeModel;
    }

    public void setPlaneModel(String planeModel) {
        this.planeModel = planeModel;
    }

    @Override
    public String toString()
    {
        return "Airline Name: "+ airlineName + " Plane Model: "+ planeModel;
    }
}
